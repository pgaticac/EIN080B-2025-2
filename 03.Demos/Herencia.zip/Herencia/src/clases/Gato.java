package clases;

public class Gato extends Animal {

    @Override
    public String comunicarse() {
        return "Miau!";
    }
    
}
