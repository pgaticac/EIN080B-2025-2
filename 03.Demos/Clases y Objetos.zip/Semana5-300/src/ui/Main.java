package ui;

import clases.Paciente;

public class Main {

    public static void main(String[] args) {
        Paciente paciente1;

        paciente1 = new Paciente();

        paciente1.setNombre("Cucha");
        paciente1.setEspecie("Gato");
        paciente1.setRaza("Romano");
        paciente1.setEdad(8);
        
        System.out.println(paciente1.imprimirDatos());

        
        Paciente paciente2 = new Paciente("Frank","perro","pug",1);
        System.out.println(paciente2.imprimirDatos());
        
    }

}
