package clases;

public class Paciente {

    private String nombre;
    private String especie;
    private String raza;
    private int edad;

    //Constructor por defecto
    public Paciente() {
    }

    //Constructor personalizado
    public Paciente(String nombre, String especie, String raza, int edad) {
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
    }
    
    //accesador / getter
    public int getEdad() {
        return this.edad;
    }
    
    //mutador / setter
    public void setEdad(int edad){
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }
    
    //Métodos de Negocio
    public String imprimirDatos(){
        String datos = "\nFicha Paciente\nNombre: " + this.nombre +
                       "\nEspecie: "+ this.especie +
                       "\nRaza: "+ this.raza +
                       "\nEdad: "+ this.edad;
                
        
        return datos;
    }
}
